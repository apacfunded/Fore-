'use client';
import { FormEvent, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import GolfCourse, { Playback } from '@/components/GolfCourse';
import { buildRound, describeShot } from '@/lib/game';
import { ADDRESS_RE, CALLOUT_RE, HANDLE_RE } from '@/lib/entry';

type Player = { handle: string; wallet: string };
type State = {
  now: number;
  round: { id: number; endsAt: number; players: Player[] };
  poolLamports: number;
  poolInfo: { solUsd: number | null; volumeH24Usd: number | null; feePct: number; unlocked: boolean; minLamports: number };
  payoutShare: number;
  maxPayoutLamports: number;
  roundMs: number;
  tiers: { minSol: number; seconds: number }[];
  lastRound: null | { id: number; seed: number; blockhash: string | null; settledAt: string | null; payoutLamports: number; practice: boolean; players: Player[] };
  winners: { round: number; handle: string; wallet: string; lamports: number; status: string; tx: string | null }[];
};

const SYMBOL = process.env.NEXT_PUBLIC_TOKEN_SYMBOL || 'FORE';
const sol = (l: number) => (l / 1e9).toFixed(3);
const dur = (ms: number) => { const s = Math.round(ms / 1000); return s < 60 ? `${s} sec` : s % 60 === 0 ? `${s / 60} min` : `${Math.floor(s / 60)}m ${s % 60}s`; };
const usd = (n: number) => '$' + (n >= 1000 ? Math.round(n).toLocaleString() : n.toFixed(2));
const ADDR_KEY = 'cob-address';

export default function Home() {
  const [me, setMe] = useState<string | undefined>();
  useEffect(() => { try { setMe(localStorage.getItem(ADDR_KEY) || undefined); } catch {} }, []);
  const [state, setState] = useState<State | null>(null);
  const [offset, setOffset] = useState(0);
  const [netErr, setNetErr] = useState('');
  const [playback, setPlayback] = useState<(Playback & { winnerEnd: number; total: number; payout: number; practice: boolean }) | null>(null);
  const seenRound = useRef<number | null>(null);
  const [, force] = useState(0);

  // Poll the game server.
  const load = useCallback(async () => {
    try {
      const r = await fetch('/api/state', { cache: 'no-store' });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error || 'Server error');
      setState(d);
      setOffset(d.now - Date.now());
      setNetErr('');
      const lr = d.lastRound as State['lastRound'];
      if (lr) {
        const fresh = lr.settledAt && Date.now() + (d.now - Date.now()) - new Date(lr.settledAt).getTime() < 15000;
        if (seenRound.current !== null && seenRound.current !== lr.id && fresh) {
          const built = buildRound(lr.seed, lr.players.length);
          setPlayback({
            roundId: lr.id, shots: built.shots, winner: built.winner,
            players: lr.players.map((p) => p.handle), startedAt: Date.now(),
            winnerEnd: built.winnerEnd, total: built.total, payout: lr.payoutLamports, practice: lr.practice,
          });
        }
        seenRound.current = lr.id;
      } else if (seenRound.current === null) {
        seenRound.current = -1;
      }
    } catch {
      setNetErr('Lost connection to the game. Retrying…');
    }
  }, []);

  useEffect(() => {
    load();
    const a = setInterval(load, 2000);
    const b = setInterval(() => force((n) => n + 1), 250);
    return () => { clearInterval(a); clearInterval(b); };
  }, [load]);

  const serverNow = Date.now() + offset;
  const el = playback ? (Date.now() - playback.startedAt) / 1000 : 0;
  const playing = !!playback && el < playback.total;
  const showWinner = !!playback && el >= playback.winnerEnd && el < playback.total;

  const msLeft = state ? Math.max(0, state.round.endsAt - serverNow) : 60000;
  const clock = `${Math.floor(Math.ceil(msLeft / 1000) / 60)}:${String(Math.ceil(msLeft / 1000) % 60).padStart(2, '0')}`;
  const roundMs = state?.roundMs ?? 60000;
  const players = state?.round.players ?? [];
  const locked = !!state && !state.poolInfo.unlocked;
  const nextWin = state ? Math.min(state.poolLamports * state.payoutShare, state.maxPayoutLamports) : 0;
  const fillPct = state ? Math.min(100, (state.poolLamports / state.poolInfo.minLamports) * 100) : 0;

  // Last round's results table (hidden until its playback finishes, so the result isn't spoiled).
  const results = useMemo(() => {
    const lr = state?.lastRound;
    if (!lr) return null;
    const built = buildRound(lr.seed, lr.players.length);
    const rows = built.shots
      .map((s) => ({ s, p: lr.players[s.index] }))
      .sort((a, b) => (a.s.kind === 'hole' ? -1 : b.s.kind === 'hole' ? 1 : Math.abs(a.s.xF - 860) - Math.abs(b.s.xF - 860)));
    return { lr, rows, winner: lr.players[built.winner] };
  }, [state?.lastRound]);
  const hideResults = playing && playback?.roundId === results?.lr.id && !showWinner;

  let overlay: { big: string; who: string; sub: string; idle: boolean } | null = null;
  const minSol = state ? sol(state.poolInfo.minLamports) : '5';
  if (showWinner && playback) overlay = playback.practice
    ? { big: 'HOLE IN ONE', who: playback.players[playback.winner], sub: `Practice round · payouts start when the pool hits ${minSol} SOL`, idle: false }
    : { big: 'HOLE IN ONE', who: playback.players[playback.winner], sub: `+${sol(playback.payout)} SOL from the pool`, idle: false };
  else if (!playing) {
    overlay = msLeft > 0
      ? { big: locked ? 'PRACTICE ROUND' : 'NEXT TEE OFF', who: clock, sub: locked ? `No payouts until the pool hits ${minSol} SOL` : players.length ? `${players.length} on the tee` : 'Waiting for callouts', idle: true }
      : { big: 'TEEING OFF', who: '…', sub: players.length ? 'Drawing the winner' : 'No callouts, pool rolls over', idle: true };
  }

  return (
    <div className="wrap">
      <header className="top">
        <div>
          <h1>FORE<span>!</span></h1>
          <p className="tag">Yell FORE on pump.fun to get a ball on the tee. Everyone on the tee swings together, and the bigger the pool, the faster rounds come. Hole in one takes {Math.round((state?.payoutShare ?? 0.1) * 100)}% of the pool, up to {state ? parseFloat(sol(state.maxPayoutLamports)) : 0.5} SOL.</p>
        </div>
      </header>

      <div className="grid">
        <div className="course">
          <GolfCourse playback={playing ? playback : null} teeCount={players.length} />
          <div className="hud">
            <span>Round #{state?.round.id ?? '–'}</span>
            <span>Par 3 · 162 yds</span>
            <span>{players.length} {players.length === 1 ? 'ball' : 'balls'}</span>
          </div>
          {overlay && (
            <div className={`overlay${overlay.idle ? ' idle' : ''}`}>
              <div className="box"><div className="big">{overlay.big}</div><div className="who">{overlay.who}</div><div className="sub">{overlay.sub}</div></div>
            </div>
          )}
        </div>

        <aside className="rail">
          <div className="card">
            <p className="label">Prize pool</p>
            <div className="pool">{state ? sol(state.poolLamports) : '–'} <small>SOL</small></div>
            {locked && state ? (<>
              <p className="payout">Payouts start at <b>{sol(state.poolInfo.minLamports)} SOL</b></p>
              <div className="bar" aria-label={`Pool is ${Math.floor(fillPct)}% full`}><i style={{ width: `${fillPct}%`, background: 'var(--good)' }} /></div>
              <p className="hint" style={{ marginTop: 6 }}>{Math.floor(fillPct)}% full · {sol(Math.max(0, state.poolInfo.minLamports - state.poolLamports))} SOL to go. Until then, rounds are practice: you can play and win, but nobody gets paid.</p>
            </>) : <p className="payout">Next hole in one wins <b>{state ? sol(nextWin) : '–'} SOL</b></p>}
            {state?.poolInfo.volumeH24Usd != null && (
              <p className="hint" style={{ marginTop: 6 }}>
                Estimated from ${SYMBOL} trading: {usd(state.poolInfo.volumeH24Usd)} volume in 24h × {state.poolInfo.feePct}% creator fee
                {state.poolInfo.solUsd ? ` · 1 SOL ≈ ${usd(state.poolInfo.solUsd)}` : ''}
              </p>
            )}
            {netErr && <p className="msg err">{netErr}</p>}
          </div>

          <div className="card clock">
            <p className="label">{playing ? 'Balls in the air' : locked ? 'Practice tee off in' : 'Tee off in'}</p>
            <div className="t">{playing ? `${Math.floor(el)}s` : clock}</div>
            <div className="bar"><i style={{ width: `${playing ? 100 : Math.max(0, 100 - (msLeft / roundMs) * 100)}%` }} /></div>
            {state && (locked
              ? <p className="hint" style={{ marginTop: 8 }}>Practice rounds every {dur(roundMs)}.</p>
              : <>
                  <p className="hint" style={{ marginTop: 8 }}>Bigger pool, faster rounds. Right now: a round every <b>{dur(roundMs)}</b>.</p>
                  <table style={{ marginTop: 6, fontSize: 12.5 }}><tbody>
                    {state.tiers.map((t, i) => {
                      const next = state.tiers[i + 1];
                      const on = state.poolLamports / 1e9 >= t.minSol && (!next || state.poolLamports / 1e9 < next.minSol);
                      return (
                        <tr key={t.minSol} className={on ? 'win' : ''}>
                          <td>{next ? `${t.minSol}–${next.minSol} SOL` : `${t.minSol}+ SOL`}</td>
                          <td className="r">every {dur(t.seconds * 1000)}</td>
                        </tr>
                      );
                    })}
                  </tbody></table>
                </>)}
          </div>

          <EntryCard
            roundId={state?.round.id ?? null}
            onEntered={(addr) => { setMe(addr); try { localStorage.setItem(ADDR_KEY, addr); } catch {} load(); }}
            savedAddress={me}
            alreadyIn={!!me && players.some((p) => p.wallet === me)}
            practiceUntil={locked ? minSol : null}
          />

          <div className="card">
            <p className="label">On the tee · {players.length}</p>
            {players.length ? (
              <ul className="queue">{players.map((p) => <li key={p.wallet} className={p.wallet === me ? 'you' : ''}>{p.handle}</li>)}</ul>
            ) : <p className="empty">No callouts yet. If nobody enters, the pool rolls over.</p>}
          </div>
        </aside>
      </div>

      <div className="lower">
        <div className="card">
          <h2>Last round{results?.lr.practice && !hideResults ? ' · practice' : ''}</h2>
          {!results ? <p className="empty">Results show here after the first tee off.</p>
            : hideResults ? <p className="empty">Round {results.lr.id} is in the air…</p>
            : (
              <>
                <div className="tbl"><table><tbody>
                  {results.rows.map(({ s, p }) => (
                    <tr key={p.wallet} className={s.kind === 'hole' ? 'win' : ''}>
                      <td className="h">{p.handle}</td>
                      <td className="r">{s.kind === 'hole' ? (results.lr.practice ? 'Hole in one · practice, no payout' : `Hole in one · +${sol(results.lr.payoutLamports)} SOL`) : describeShot(s)}</td>
                    </tr>
                  ))}
                </tbody></table></div>
                <p className="seed">
                  Round {results.lr.id} · seed = first 8 hex of sha256(&quot;{results.lr.blockhash}:{results.lr.id}&quot;) = {results.lr.seed} · {results.lr.seed} mod {results.lr.players.length} = {results.lr.seed % results.lr.players.length} → {results.winner.handle}
                </p>
              </>
            )}
        </div>
        <div className="card">
          <h2>Hole-in-one winners</h2>
          {state?.winners.length ? (
            <ul className="feed">
              {state.winners.filter((w) => !(playing && playback?.roundId === w.round && !showWinner)).map((w) => (
                <li key={w.round}>
                  <span><span className="h">{w.handle}</span> <span style={{ color: 'var(--ink-soft)' }}>· round {w.round}</span></span>
                  {w.status === 'paid' && w.tx
                    ? <a className="amt" href={`https://solscan.io/tx/${w.tx}`} target="_blank" rel="noreferrer">+{sol(w.lamports)} SOL ↗</a>
                    : w.status === 'skipped' ? <span className="amt pending">not paid</span>
                    : <span className="amt pending">+{sol(w.lamports)} SOL · {w.status === 'paid' ? 'paid' : 'sending'}</span>}
                </li>
              ))}
            </ul>
          ) : <p className="empty">No winners yet.</p>}
        </div>
      </div>

      <p className="how">
        <b>How to play:</b> post a callout for ${SYMBOL} on pump.fun, paste the link, and add the Solana address you want to be paid to. One ball per person per round, and each callout link works once.
        {' '}<b>How the winner is picked:</b> when a round ends, the server takes the latest finalized Solana blockhash, hashes it with the round number, and uses that as the seed. Seed mod the number of balls picks the winner, and every visitor&apos;s screen plays out the same shots from the same seed.
        {' '}<b>The pool</b> is an estimate of creator rewards from the coin&apos;s trading volume on DexScreener. Winnings are sent by hand, usually soon after the round.
      </p>
    </div>
  );
}

function EntryCard({ roundId, onEntered, savedAddress, alreadyIn, practiceUntil }: {
  roundId: number | null; onEntered: (address: string) => void; savedAddress?: string; alreadyIn: boolean; practiceUntil: string | null;
}) {
  const [handle, setHandle] = useState('');
  const [link, setLink] = useState('');
  const [address, setAddress] = useState('');
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  useEffect(() => { if (savedAddress && !address) setAddress(savedAddress); }, [savedAddress]); // eslint-disable-line react-hooks/exhaustive-deps

  async function submit(e: FormEvent) {
    e.preventDefault();
    setMsg(null);
    const url = link.trim();
    const addr = address.trim();
    if (roundId == null) return setMsg({ ok: false, text: 'The game is still loading. Try again in a second.' });
    if (!CALLOUT_RE.test(url)) return setMsg({ ok: false, text: 'Paste the link to your callout on pump.fun.' });
    if (!ADDRESS_RE.test(addr)) return setMsg({ ok: false, text: 'Enter the Solana address you want to be paid to.' });
    if (handle && !HANDLE_RE.test(handle)) return setMsg({ ok: false, text: 'Names use letters, numbers and underscores, up to 20.' });
    setBusy(true);
    try {
      const r = await fetch('/api/enter', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ wallet: addr, handle: handle.trim(), calloutUrl: url, roundId }),
      });
      const d = await r.json();
      if (!r.ok) setMsg({ ok: false, text: d.error || 'Could not enter.' });
      else { setMsg({ ok: true, text: `You're on the tee for round ${d.roundId}.` }); setLink(''); onEntered(addr); }
    } catch {
      setMsg({ ok: false, text: 'Could not reach the game. Try again.' });
    } finally { setBusy(false); }
  }

  return (
    <div className="card">
      <p className="label">Get on the tee</p>
      <form className="enter" onSubmit={submit} noValidate>
        <input id="link" placeholder="pump.fun link to your callout" value={link} onChange={(e) => setLink(e.target.value)} autoComplete="off" aria-label="pump.fun callout link" />
        <input id="address" placeholder="Solana address to get paid" value={address} onChange={(e) => setAddress(e.target.value)} autoComplete="off" spellCheck={false} aria-label="Solana payout address" />
        <input id="handle" placeholder="Name on your ball (optional)" value={handle} onChange={(e) => setHandle(e.target.value)} autoComplete="off" aria-label="Name on your ball" />
        <button className="cta" type="submit" disabled={busy || alreadyIn}>
          {alreadyIn ? "You're in this round" : busy ? 'Entering…' : practiceUntil ? 'Enter practice round' : 'Enter next round'}
        </button>
        <p className={`msg ${msg ? (msg.ok ? 'ok' : 'err') : ''}`} role="status">{msg?.text}</p>
        {practiceUntil && <p className="hint" style={{ color: 'var(--flag)', fontWeight: 600 }}>Practice round: winners won&apos;t be paid until the pool reaches {practiceUntil} SOL.</p>}
        <p className="hint">Double-check the address. Winnings go exactly where you tell us.</p>
      </form>
    </div>
  );
}
