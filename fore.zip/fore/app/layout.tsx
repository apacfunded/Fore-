import type { Metadata } from 'next';
import { Bowlby_One, Figtree, JetBrains_Mono } from 'next/font/google';
import './globals.css';

const display = Bowlby_One({ weight: '400', subsets: ['latin'], variable: '--f-display' });
const body = Figtree({ subsets: ['latin'], variable: '--f-body' });
const mono = JetBrains_Mono({ weight: ['500', '700'], subsets: ['latin'], variable: '--f-mono' });

export const metadata: Metadata = {
  title: 'Fore!',
  description: 'Yell FORE on pump.fun to get a ball on the tee. Bigger pool, faster rounds. Hole in one takes 10% of the pool.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${display.variable} ${body.variable} ${mono.variable}`}>
      <body>{children}</body>
    </html>
  );
}
