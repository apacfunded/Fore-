'use client';
import { useEffect, useRef } from 'react';
import { COURSE, posAt, Shot } from '@/lib/game';

export type Playback = {
  roundId: number;
  shots: Shot[];
  winner: number;
  players: string[];
  startedAt: number; // Date.now() when playback began
};

type Props = { playback: Playback | null; teeCount: number };

const { W, H, GY, CUP, POND, BUNKER, GREEN, TEE } = COURSE;

export default function GolfCourse({ playback, teeCount }: Props) {
  const ref = useRef<HTMLCanvasElement>(null);
  const live = useRef({ playback, teeCount });
  live.current = { playback, teeCount };

  useEffect(() => {
    const cv = ref.current!;
    const ctx = cv.getContext('2d')!;
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const trees = Array.from({ length: 22 }, (_, i) => ({ x: i * 48 + ((i * 37) % 20) - 10, h: 40 + ((i * 53) % 40), w: 26 + ((i * 29) % 14) }));
    let effects = { roundId: -1, splashes: new Map<number, number>(), confetti: [] as { x: number; y: number; vx: number; vy: number; c: string }[], dropped: false };
    let raf = 0;
    let last = performance.now();

    const resize = () => {
      const w = cv.clientWidth || 1000;
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      cv.width = Math.round(w * dpr);
      cv.height = Math.round((w * H) / W * dpr);
      ctx.setTransform(cv.width / W, 0, 0, cv.height / H, 0, 0);
    };
    resize();
    window.addEventListener('resize', resize);

    const scene = (t: number) => {
      const sky = ctx.createLinearGradient(0, 0, 0, GY);
      sky.addColorStop(0, '#5FA6D6'); sky.addColorStop(1, '#CDE6F2');
      ctx.fillStyle = sky; ctx.fillRect(0, 0, W, H);
      ctx.fillStyle = '#8FBF9A'; ctx.beginPath(); ctx.moveTo(0, GY - 60);
      for (let x = 0; x <= W; x += 20) ctx.lineTo(x, GY - 70 - Math.sin(x / 140) * 22 - Math.sin(x / 53) * 8);
      ctx.lineTo(W, GY); ctx.lineTo(0, GY); ctx.fill();
      ctx.fillStyle = '#3F7A52';
      for (const tr of trees) { ctx.beginPath(); ctx.ellipse(tr.x, GY - 18 - tr.h / 2, tr.w / 2, tr.h / 2, 0, 0, Math.PI * 2); ctx.fill(); }
      ctx.fillStyle = '#4E9A4F'; ctx.fillRect(0, GY, W, H - GY);
      ctx.fillStyle = '#62AE5B'; ctx.fillRect(0, GY, W, 8);
      ctx.fillStyle = 'rgba(255,255,255,.05)'; for (let x = 0; x < W; x += 60) ctx.fillRect(x, GY + 8, 30, H - GY);
      ctx.fillStyle = '#3C8141'; ctx.fillRect(0, GY + 44, W, H - GY - 44);
      ctx.fillStyle = '#7CC46E'; ctx.fillRect(40, GY, 90, 8);
      ctx.fillStyle = '#fff'; ctx.fillRect(48, GY - 6, 4, 6); ctx.fillRect(118, GY - 6, 4, 6);
      ctx.fillStyle = '#2D6FA3'; ctx.beginPath(); ctx.ellipse((POND[0] + POND[1]) / 2, GY + 4, (POND[1] - POND[0]) / 2, 10, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = 'rgba(255,255,255,.25)'; ctx.fillRect(POND[0] + 30, GY + 1, 40, 2); ctx.fillRect(POND[0] + 80, GY + 5, 28, 2);
      ctx.fillStyle = '#E7D39A'; ctx.beginPath(); ctx.ellipse((BUNKER[0] + BUNKER[1]) / 2, GY + 3, (BUNKER[1] - BUNKER[0]) / 2, 8, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#86D17A'; ctx.beginPath(); ctx.ellipse((GREEN[0] + GREEN[1]) / 2, GY + 4, (GREEN[1] - GREEN[0]) / 2, 10, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#1C2B20'; ctx.beginPath(); ctx.ellipse(CUP, GY + 1, 7, 2.6, 0, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = '#F4F4F0'; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.moveTo(CUP, GY); ctx.lineTo(CUP, GY - 118); ctx.stroke();
      const wv = reduce ? 0 : Math.sin(t * 4) * 4;
      ctx.fillStyle = '#E0412B'; ctx.beginPath(); ctx.moveTo(CUP + 1, GY - 118);
      ctx.quadraticCurveTo(CUP + 22, GY - 112 + wv, CUP + 44, GY - 104 + wv * 0.6);
      ctx.quadraticCurveTo(CUP + 22, GY - 98 + wv, CUP + 1, GY - 92); ctx.fill();
      ctx.font = '600 11px ui-monospace, monospace'; ctx.textAlign = 'center';
      ([[TEE + 780 * (62 / 162), '100'], [TEE + 780 * (112 / 162), '50']] as [number, string][]).forEach(([x, l]) => {
        ctx.fillStyle = 'rgba(255,255,255,.85)'; ctx.fillRect(x - 1, GY - 16, 2, 16);
        ctx.fillStyle = '#fff'; ctx.fillText(l, x, GY + 30);
      });
      ctx.fillStyle = 'rgba(255,255,255,.9)'; ctx.fillText('TEE', 85, GY + 30); ctx.fillText('PIN', CUP, GY + 30);
    };

    const ball = (x: number, z: number, alpha: number, label: string | null, gold: boolean) => {
      const y = GY - 4 - z;
      const sh = Math.max(0.15, 1 - z / 260);
      ctx.fillStyle = `rgba(0,0,0,${0.25 * sh * alpha})`;
      ctx.beginPath(); ctx.ellipse(x, GY + 1, 5 * sh + 1, 1.8 * sh + 0.5, 0, 0, Math.PI * 2); ctx.fill();
      ctx.globalAlpha = alpha;
      ctx.fillStyle = gold ? '#F2C230' : '#FFFFFF';
      ctx.beginPath(); ctx.arc(x, y, 4.6, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = 'rgba(0,0,0,.25)'; ctx.lineWidth = 1; ctx.stroke();
      ctx.globalAlpha = 1;
      if (label) {
        ctx.font = '700 12px ui-monospace, monospace';
        const w = ctx.measureText(label).width + 10;
        const lx = Math.min(Math.max(x - w / 2, 4), W - w - 4), ly = y - 24;
        ctx.fillStyle = gold ? 'rgba(242,194,48,.95)' : 'rgba(14,36,25,.82)';
        ctx.beginPath(); ctx.roundRect(lx, ly, w, 17, 4); ctx.fill();
        ctx.fillStyle = gold ? '#10251A' : '#fff'; ctx.textAlign = 'left'; ctx.fillText(label, lx + 5, ly + 12.5);
      }
    };

    const frame = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000); last = now;
      const { playback: pb, teeCount: tc } = live.current;
      scene(now / 1000);

      if (!pb) {
        for (let i = 0; i < Math.min(tc, 6); i++) ball(60 + i * 9, 0, 1, null, false);
      } else {
        if (effects.roundId !== pb.roundId) effects = { roundId: pb.roundId, splashes: new Map(), confetti: [], dropped: false };
        const el = (Date.now() - pb.startedAt) / 1000;
        const waiting = pb.shots.filter((s) => el < s.launch).length;
        // Balls for the next round wait on the tee once this round's balls are all away.
        const onTee = waiting > 0 ? waiting : tc;
        for (let i = 0; i < Math.min(onTee, 6); i++) ball(60 + i * 9, 0, waiting > 0 ? 1 : 0.9, null, false);

        const flying: { s: Shot; x: number; z: number }[] = [];
        for (const s of pb.shots) {
          const p = posAt(s, el - s.launch);
          if (!p) continue;
          if (p.splash && !effects.splashes.has(s.index)) effects.splashes.set(s.index, el);
          if (p.gone && s.end === 'drop' && !effects.dropped) {
            effects.dropped = true;
            const cols = ['#F2C230', '#E0412B', '#fff', '#86D17A'];
            for (let i = 0; i < 70; i++) effects.confetti.push({ x: CUP, y: GY - 4, vx: (Math.random() - 0.5) * 320, vy: -140 - Math.random() * 200, c: cols[i % 4] });
          }
          if (p.gone) continue;
          if (p.sink !== undefined) { ball(p.x, p.z, 1 - p.sink, null, true); continue; }
          if (p.rest) ball(p.x, p.z, 0.9, null, false);
          else flying.push({ s, x: p.x, z: p.z });
        }
        const tagged = flying.slice(-3);
        for (const f of flying) ball(f.x, f.z, 1, tagged.includes(f) ? pb.players[f.s.index] : null, false);

        effects.splashes.forEach((t0) => {
          const a = el - t0; if (a > 1.2) return;
          const s = pb.shots.find((q) => effects.splashes.get(q.index) === t0)!;
          ctx.strokeStyle = `rgba(255,255,255,${0.8 * (1 - a / 1.2)})`; ctx.lineWidth = 2;
          ctx.beginPath(); ctx.ellipse(s.xF, GY + 3, 6 + a * 26, 2 + a * 6, 0, 0, Math.PI * 2); ctx.stroke();
        });
        if (!reduce) for (const c of effects.confetti) {
          c.vy += 520 * dt; c.x += c.vx * dt; c.y += c.vy * dt;
          if (c.y < GY + 6) { ctx.fillStyle = c.c; ctx.fillRect(c.x, c.y, 4, 6); }
        }
      }
      raf = requestAnimationFrame(frame);
    };
    raf = requestAnimationFrame(frame);
    return () => { cancelAnimationFrame(raf); window.removeEventListener('resize', resize); };
  }, []);

  return <canvas ref={ref} width={1000} height={480} aria-label="Golf hole with balls teeing off toward the pin" />;
}
