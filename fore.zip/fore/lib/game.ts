// Shared by the server and the browser. Given a round's seed and entry count,
// everyone computes the same winner and the same shot for every ball, so all
// visitors watch the identical round and anyone can re-check the result.

export const COURSE = {
  W: 1000, H: 480, GY: 380, TEE: 80, CUP: 860,
  POND: [385, 520] as const,
  BUNKER: [640, 705] as const,
  GREEN: [755, 965] as const,
};
const FT_PER_UNIT = (162 * 3) / (COURSE.CUP - COURSE.TEE);

export type ShotKind = 'hole' | 'water' | 'bunker' | 'fairway' | 'green' | 'long';
export type Seg = { t: 'arc' | 'roll'; x0: number; x1: number; h: number; d: number };
export type Shot = {
  index: number;          // entry index in the round (entry order)
  kind: ShotKind;
  xF: number;             // final resting x
  segs: Seg[];
  end: 'rest' | 'splash' | 'drop';
  dur: number;            // seconds from launch to finish
  launch: number;         // seconds after round playback starts
};

/** Deterministic 32-bit PRNG. */
export function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function winnerIndex(seed: number, n: number) {
  return (seed >>> 0) % n;
}

/** Turns a hex string (from sha256) into the round's 32-bit seed. */
export function seedFromHex(hex: string) {
  return parseInt(hex.slice(0, 8), 16) >>> 0;
}

export function buildRound(seed: number, n: number): { winner: number; shots: Shot[]; winnerEnd: number; total: number } {
  const rnd = mulberry32(seed ^ 0x9e3779b9);
  const r = (a: number, b: number) => a + rnd() * (b - a);
  const { TEE, CUP, POND, BUNKER } = COURSE;
  const winner = winnerIndex(seed, n);

  // Tee-off order: everyone shuffled, winner goes second to last for suspense.
  const order = Array.from({ length: n }, (_, i) => i).filter((i) => i !== winner);
  for (let i = order.length - 1; i > 0; i--) {
    const j = Math.floor(rnd() * (i + 1));
    [order[i], order[j]] = [order[j], order[i]];
  }
  order.splice(Math.max(order.length - 1, 0), 0, winner);
  const gap = Math.min(0.55, 6 / n);

  const shots: Shot[] = order.map((idx, k) => {
    const isWin = idx === winner;
    let kind: ShotKind;
    let xF = CUP;
    if (isWin) kind = 'hole';
    else {
      const p = rnd();
      kind = p < 0.2 ? 'water' : p < 0.35 ? 'bunker' : p < 0.55 ? 'fairway' : p < 0.9 ? 'green' : 'long';
      if (kind === 'bunker') xF = r(BUNKER[0] + 8, BUNKER[1] - 8);
      if (kind === 'fairway') xF = rnd() < 0.6 ? r(545, 632) : r(712, 752);
      if (kind === 'green') xF = rnd() < 0.5 ? r(772, 842) : r(878, 955);
      if (kind === 'long') xF = r(972, 994);
    }
    const segs: Seg[] = [];
    let end: Shot['end'] = 'rest';
    const h = r(150, 235);
    if (kind === 'water') {
      const xL = r(POND[0] + 12, POND[1] - 12);
      segs.push({ t: 'arc', x0: TEE, x1: xL, h, d: 1.3 + ((xL - TEE) / 780) * 0.9 });
      end = 'splash';
      xF = xL;
    } else {
      let run = kind === 'bunker' ? r(6, 16) : r(35, 95);
      run = Math.min(run, Math.max(6, xF - 545));
      const xL = xF - run;
      segs.push({ t: 'arc', x0: TEE, x1: xL, h, d: 1.3 + ((xL - TEE) / 780) * 0.9 });
      if (kind === 'bunker') segs.push({ t: 'arc', x0: xL, x1: xF, h: h * 0.02, d: 0.25 });
      else {
        const b1 = run * 0.42, b2 = run * 0.2;
        segs.push({ t: 'arc', x0: xL, x1: xL + b1, h: h * 0.12, d: 0.45 });
        segs.push({ t: 'arc', x0: xL + b1, x1: xL + b1 + b2, h: h * 0.035, d: 0.26 });
        segs.push({ t: 'roll', x0: xL + b1 + b2, x1: xF, h: 0, d: isWin ? 1.3 : 0.95 });
      }
      if (isWin) end = 'drop';
    }
    const dur = segs.reduce((s, g) => s + g.d, 0) + (end === 'drop' ? 0.35 : 0);
    return { index: idx, kind, xF, segs, end, dur, launch: k * gap };
  });

  const ws = shots.find((s) => s.index === winner)!;
  const winnerEnd = ws.launch + ws.dur;
  const total = Math.max(...shots.map((s) => s.launch + s.dur), winnerEnd) + 4;
  return { winner, shots, winnerEnd, total };
}

export function describeShot(s: Shot): string {
  const { CUP } = COURSE;
  if (s.kind === 'hole') return 'Hole in one';
  if (s.kind === 'water') return 'In the pond';
  if (s.kind === 'bunker') return 'In the bunker';
  if (s.kind === 'long') return 'Over the green';
  const ft = Math.round(Math.abs(CUP - s.xF) * FT_PER_UNIT);
  const dir = s.xF < CUP ? 'short' : 'long';
  return s.kind === 'fairway' ? `${Math.round(ft / 3)} yds ${dir}` : `${ft} ft ${dir}`;
}

export type BallPos = { x: number; z: number; fly?: boolean; rest?: boolean; gone?: boolean; splash?: boolean; sink?: number };

export function posAt(s: Shot, t: number): BallPos | null {
  if (t < 0) return null;
  let acc = 0;
  for (const g of s.segs) {
    if (t <= acc + g.d) {
      const p = (t - acc) / g.d;
      if (g.t === 'arc') return { x: g.x0 + (g.x1 - g.x0) * p, z: 4 * g.h * p * (1 - p), fly: g.h > 40 };
      const e = 1 - Math.pow(1 - p, 3);
      return { x: g.x0 + (g.x1 - g.x0) * e, z: 0 };
    }
    acc += g.d;
  }
  if (s.end === 'splash') return { x: s.xF, z: 0, gone: true, splash: true };
  if (s.end === 'drop') {
    const p = Math.min(1, (t - acc) / 0.35);
    return { x: COURSE.CUP, z: -p * 10, sink: p, gone: p >= 1 };
  }
  return { x: s.xF, z: 0, rest: true };
}
